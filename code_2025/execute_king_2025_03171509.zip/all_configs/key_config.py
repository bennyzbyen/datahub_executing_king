cal_dict = [
    {"numerator_col": "get_mh_sku_count", "denominator_col": "target_mh_sku_count", "result_col": "mh_sku_rate_tops"},
    {"numerator_col": "get_mh_sku_count_choc", "denominator_col": "target_mh_sku_count_choc", "result_col": "mh_sku_rate_choc"},
    {"numerator_col": "get_mh_sku_count_gum", "denominator_col": "target_mh_sku_count_gum", "result_col": "mh_sku_rate_gum"},
    {"numerator_col": "get_mh_sku_count_mint", "denominator_col": "target_mh_sku_count_mint", "result_col": "mh_sku_rate_mint"},
    {"numerator_col": "get_mh_sku_count_fc", "denominator_col": "target_mh_sku_count_fc", "result_col": "mh_sku_rate_fc"},
    ]
